using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine.UI;
using UnityEngine;

public class Movement : MonoBehaviour {

    private GameObject ob;
    public GameObject shot;
    private Rigidbody2D myBody;

    public AudioSource shoot;
    public AudioSource jump;
    public AudioSource die;
    public AudioSource boing;

    public UIHelper u;
    public Text t;
    //public Canvas start;

    public int checkpoint = 0;

    public float moveSpeed = 3f;
    public float health = 100f;
    public float damage = 3f;

    private float timer = 90000f;
    public int respawn = 0;

    public float shot_speed = 3f;
    private float shot_timer = 0.75f;

    private float fade_timer = 1f;

    private bool isTurned = false;
    private bool isGrounded = false;
    public bool canMove = true;
    private bool canJump = true;
    private bool onWall = false;
    public bool isHandled = false;
    public bool canShoot = true;
    private bool isStart = true;
    private bool isFaded = false;
    private bool notEnd = true;

    void Awake() {
        //t.enabled = false;
        ob = GameObject.FindGameObjectWithTag("Player");
        myBody = GetComponent<Rigidbody2D>();
    }

    private void Start() {
        //start.enabled = true;
        t.enabled = false;
        string pos = File.ReadAllText("Dot_Save.txt");
        string[] xy = pos.Split(',');
        ob.transform.position = new Vector2(float.Parse(xy[0]), float.Parse(xy[1]));
    }

    private void Update() {
        Checkpoint();

        if (health <= 0 && !isHandled) {
            isHandled = true;
            Died();
        }

        if (checkpoint == 0 && respawn == 2) {
            ob.transform.position = new Vector2(170f, 4f);
            respawn = 3;
        }

        if (!canShoot)
            shot_timer -= Time.deltaTime;
        if (shot_timer <= 0) {
            shot_timer = 0.75f;
            canShoot = true;
        }

        if (isFaded && notEnd)
            fade_timer -= Time.deltaTime;
        if (fade_timer <= 0f) {
            if (checkpoint == 1) {
                checkpoint = 2;
                ob.transform.position = new Vector2(270f, 4f);
            }
            isFaded = false;
            fade_timer = 1f;
            unfade();
        }
    }

    void  Checkpoint() {
        if (ob.transform.position.x > -25 && ob.transform.position.x < 120)
            checkpoint = 0;
        else if (ob.transform.position.x > 120 && ob.transform.position.x < 185)
            checkpoint = 1;
        else if (ob.transform.position.x > 185 && ob.transform.position.x < 300)
            checkpoint = 2;
    }

    void Died() {
        canMove = false;
        die.Play();
        respawn = 1;
    }

    void FixedUpdate() {
        Move();
    }

    private void OnCollisionEnter2D(Collision2D collision) {

        if (collision.gameObject.tag == "Ground") {
            ob.GetComponent<Rigidbody2D>().sharedMaterial.friction = 3;
            ob.GetComponent<Rigidbody2D>().gravityScale = 1f;
            isGrounded = true;
            canMove = true;
        }
        else if (collision.gameObject.tag == "Bound") {
            ob.GetComponent<Rigidbody2D>().sharedMaterial.friction = 3;
            ob.GetComponent<Rigidbody2D>().gravityScale = 1f;
            canJump = false;
        }
        else if (collision.gameObject.tag == "Wall") {
            ob.GetComponent<Rigidbody2D>().sharedMaterial.friction = 3;
            ob.GetComponent<Rigidbody2D>().gravityScale = 1f;
            canMove = true;
            onWall = true;
        }
        else if (collision.gameObject.tag == "Bouncy") {
            ob.GetComponent<Rigidbody2D>().sharedMaterial.friction = 3;
            ob.GetComponent<Rigidbody2D>().gravityScale = 1f;
            canMove = true;
            boing.Play();
            myBody.velocity = new Vector2(myBody.velocity.x, 30f);
        }
        else if (collision.gameObject.tag == "Bouncy2") {
            ob.GetComponent<Rigidbody2D>().sharedMaterial.friction = 3;
            ob.GetComponent<Rigidbody2D>().gravityScale = 1f;
            canMove = true;
            boing.Play();
            myBody.velocity = new Vector2(myBody.velocity.x, 15f);
        }
        else if (collision.gameObject.tag == "Slidy") {
            ob.GetComponent<Rigidbody2D>().sharedMaterial.friction = 3;
            ob.GetComponent<Rigidbody2D>().gravityScale = 1f;
            canMove = false;
            myBody.velocity = new Vector2(myBody.velocity.x, -30f);
        }
        else if (collision.gameObject.tag == "Icy") {
            canMove = true;
            isGrounded = true;
            ob.GetComponent<Rigidbody2D>().gravityScale = .85f;
            ob.GetComponent<Rigidbody2D>().sharedMaterial.friction = 0.05f;
        }
        
    }

    private void OnTriggerEnter2D(Collider2D collision) {
        if (collision.gameObject.tag == "Club") {
            health -= 25f;
        }
        if (collision.gameObject.tag == "Map2") {
            isFaded = true;
            fade();
        }
        if (collision.gameObject.tag == "Map3") {
            notEnd = false;
            isFaded = true;
            fade();
            t.enabled = true;
            checkpoint = 3;
        }
    }

    private void OnCollisionExit2D(Collision2D collision) {
        if (collision.gameObject.tag == "Ground") {
            jump.Play();
            isGrounded = false;
            canMove = false;
        }
        else if (collision.gameObject.tag == "Bound") {
            canJump = true;
        }
        else if (collision.gameObject.tag == "Wall") {
            canMove = false;
            onWall = false;
        }
        else if (collision.gameObject.tag == "Slidy") {
            canMove = true;
        }
        else if (collision.gameObject.tag == "Icy") {
            canMove = false;
            isGrounded = false;
        }
    }

    void Move() {

        if (Input.GetAxisRaw("Horizontal") > 0f && canMove) {
            myBody.velocity = new Vector2(moveSpeed, myBody.velocity.y);

            if (!isTurned) {
                ob.transform.Rotate(new Vector2(0f, -5f));
                isTurned = true;
            }
        }
        if (Input.GetAxisRaw("Horizontal") < 0f && canMove) {
            myBody.velocity = new Vector2(-moveSpeed, myBody.velocity.y);

            if (isTurned) {
                ob.transform.Rotate(new Vector2(0f, 5f));
                isTurned = false;
            }
        }
        if (Input.GetAxisRaw("Vertical") > 0f && canMove && canJump) {
            if (isGrounded)
                myBody.velocity = new Vector2(myBody.velocity.x, 7f);
        }
        if (Input.GetKeyDown(KeyCode.W)  && !jump.isPlaying  && isGrounded|| Input.GetKeyDown(KeyCode.UpArrow) && !jump.isPlaying && isGrounded)
            jump.Play();

        if (Input.GetAxisRaw("Vertical") > 0f && onWall) {
            myBody.velocity = new Vector2(myBody.velocity.x, 7f);
        }
        if (Input.GetKey(KeyCode.R)) {
            ob.transform.rotation = new Quaternion(0f, 0f, 0f, 0f);
        }
        if (Input.GetKey(KeyCode.Space) && canShoot) {
            shoot.Play();
            canShoot = false;
            GameObject sx = Instantiate(shot, new Vector2(ob.transform.position.x, ob.transform.position.y + .5f), Quaternion.identity);
            //Rigidbody2D rb = sx.GetComponent<Rigidbody2D>();
            if (isTurned)
                sx.GetComponent<Rigidbody2D>().velocity = new Vector2(8f, 2f);
            if (!isTurned)
                sx.GetComponent<Rigidbody2D>().velocity = new Vector2(-8f, 2f);
            sx.GetComponent<Rigidbody2D>().bodyType = RigidbodyType2D.Dynamic;
        }
    }

    public void fade() {
        StartCoroutine(u.fade());
    }

    public void unfade() {
        StartCoroutine(u.fade(false));
    }
}