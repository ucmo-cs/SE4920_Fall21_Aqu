using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerShot : MonoBehaviour {

    private Movement m;

    private void Awake() {
        m = GameObject.FindGameObjectWithTag("Player").GetComponent<Movement>();
    }

    private void OnTriggerEnter2D(Collider2D collision) {
        if (collision.gameObject.tag == "Player")
            return;
        //Debug.Log("test");
        Destroy(gameObject);
        //m.canShoot = true;
    }
}
