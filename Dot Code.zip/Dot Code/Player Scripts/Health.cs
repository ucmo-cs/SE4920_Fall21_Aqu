using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Health : MonoBehaviour {
    public float health = 100f;
    public float damage = 3f;

    public HealthUI healthUI;

    private bool isDead = false;
    void Start() {
        healthUI = GetComponent<HealthUI>();
        
    }

    void Update() {
        
    }

    public void ApplyDamage(float damage) {
        if (isDead)
            return;

        if (health < 0f)
            isDead = true;

        health -= damage;
    }
}
