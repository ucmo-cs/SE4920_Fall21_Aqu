using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyMovement : MonoBehaviour {
    private Health hp;
    private MonsterAnimation enemyAnim;
    private Animator anim;
    private Rigidbody2D myBody;
    private BoxCollider2D box;
    public float speed = 1.8f;

    private Transform playerTarget;

    public AudioSource hurt;
    public AudioSource die;

    public float attack_Distance = 1.3f;

    public float enemy_HP = 10f;
    
    private bool followPlayer = false;
    private bool attackPlayer = true;
    private bool enemyHit = false;
    private bool hasDied = false;
    private bool enemyCanMove = true;

    private float hurt_timer = .5f;
    private float die_timer = .5f;

    private bool needTurn;
    private bool isRight;

    void Awake() {
        enemyAnim = GetComponent<MonsterAnimation>();
        anim = GetComponent<Animator>();
        myBody = GetComponent<Rigidbody2D>();
        box = GetComponent<BoxCollider2D>();

        playerTarget = GameObject.FindWithTag("Player").transform;
        
    }

    void Update() {
        float x_Dist = playerTarget.position.x - transform.position.x;
        float y_Dist = playerTarget.position.y - transform.position.y;

        if (x_Dist <= 10 && x_Dist >= -10 && y_Dist <= 3 && y_Dist >= -3)
            followPlayer = true;
        else
            followPlayer = false;

        if (followPlayer) {
            if (playerTarget.position.x > transform.position.x)
                playerRight();
            else if (playerTarget.position.x < transform.position.x)
                playerLeft();
        }

    
        if (Vector2.Distance(transform.position, playerTarget.position) > attack_Distance)
            FollowTarget();
        else if (Vector2.Distance(transform.position, playerTarget.position) <= attack_Distance)
            Attack();

        if (enemy_HP <= 0) {
            hasDied = true;
            followPlayer = false;
            attackPlayer = false;
            die.Play();
            Destroy(gameObject);
        }

        if (enemyHit) {
            hurt_timer -= Time.deltaTime;
            enemyAnim.Hurt();
        }

        if (hurt_timer <= 0 && !hasDied) {
            followPlayer = true;
            attackPlayer = true;
            enemyHit = false;
            hurt_timer = .5f;
        }
    }

    private void OnTriggerEnter2D(Collider2D collision) {
        if (collision.gameObject.tag == "PlayerShot" && !enemyHit) {
            hurt.Play();
            followPlayer = false;
            attackPlayer = false;
            enemy_HP -= 2f;
            enemyHit = true;
        }
    }

    void FollowTarget() {
        if (!followPlayer)
            return;

        enemyAnim.Walk();

        if (isRight) {
            myBody.velocity = new Vector2(speed, myBody.velocity.y);
        }
        else if (!isRight) {
            myBody.velocity = new Vector2(-speed, myBody.velocity.y);
        }
    }

    void Attack() {
        if (!attackPlayer)
            return;

        if (anim.name.Equals("Orc")) // Add for specific monsters
            enemyAnim.Smash();
    }

    void playerRight() {
        isRight = true;
        transform.localRotation = new Quaternion(0f, 180f, 0f, 0f);
    }

    void playerLeft() {
        isRight = false;
        transform.localRotation = new Quaternion(0f, 0f, 0f, 0f);
    }
}