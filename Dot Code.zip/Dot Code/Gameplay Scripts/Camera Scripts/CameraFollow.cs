using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow : MonoBehaviour {

    private Transform player;
    private Movement m;

    public float offset;

    void Start() {
        player = GameObject.FindGameObjectWithTag("Player").transform;
        m = player.GetComponent<Movement>();
    }

    void Update() {
        if (m.checkpoint == 2)
            gameObject.transform.rotation = new Quaternion(0, 0, 180, 0);
    }

    private void LateUpdate() {
        if (!(transform.position.x >= 100) || !(transform.position.x <= -90)) {

            Vector3 temp = transform.position;

            temp.x = player.position.x;
            temp.y = player.position.y + 3.5f;
            temp.x += offset;
            transform.position = temp;
        }
    }
}