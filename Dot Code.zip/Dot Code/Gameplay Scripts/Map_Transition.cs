using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Map_Transition : MonoBehaviour {

    GameObject player;
    GameObject[] gameObjects;

    private Movement m;

    public int current_map;
    public int teleport_location;
    public int checkpoint = 0;
    public string side;

    public int final = 0;
    private int place = 0;

    private void Awake() {
        gameObjects = GameObject.FindGameObjectsWithTag("Map");
    }

    // Start is called before the first frame update
    void Start() {
        Debug.Log(current_map);
        player = GameObject.FindGameObjectWithTag("Player");
        m = player.GetComponent<Movement>();

        for (int x = current_map + 1; x < gameObjects.Length; x++) { // Will Change when implementing save
            gameObjects[x].SetActive(false);
        }
    }

    // Update is called once per frame
    void Update() {
        //Debug.Log(m.health);
        if (m.respawn == 2) {
            Respawn();
        }
    }

    public void OnTriggerEnter2D(Collider2D collision) {
        if (collision.gameObject.tag != "Player")
            return;

        gameObjects[current_map].SetActive(false);
        gameObjects[teleport_location].SetActive(true);

        //Debug.Log(current_map + ", " + teleport_location);
        //Debug.Log(gameObjects[current_map] + ", " + gameObjects[teleport_location]);

        if (side.Equals("L"))
            player.transform.position = new Vector2(10.6f, player.transform.position.y);
        else if (side.Equals("R"))
            player.transform.position = new Vector2(-9.5f, player.transform.position.y);
        else if (side.Equals("T"))
            player.transform.position = new Vector2(player.transform.position.x, -4f);
        else if (side.Equals("B"))
            player.transform.position = new Vector2(player.transform.position.x, 4.6f);
    }

    public void Respawn() {
        if (checkpoint == 1) {
            m.checkpoint = 1;
            place = 8;
        }

        gameObjects[current_map].SetActive(false);
        gameObjects[place].SetActive(true);

        if (m.checkpoint == 0) {
            player.transform.position = new Vector2(2.92f, 1.49f);
            m.respawn = 4;
        }
        else if (m.checkpoint == 1) {
            player.transform.position = new Vector2(2.92f, 1.49f);
            m.respawn = 4;
        }
        else if (checkpoint == 2) {
            player.transform.position = new Vector2(2.92f, 1.49f);
            m.respawn = 4;
        }

        m.respawn = 3;
        m.health = 100f;
        m.canMove = true;
    }
}