using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MusicManager : MonoBehaviour {

    private Movement m;

    public AudioSource[] a;

    void Start() {
        m = GameObject.FindGameObjectWithTag("Player").GetComponent<Movement>();
    }

    void Update() {
        if (m.checkpoint == 0) {
            if (a[0].isPlaying)
                return;
            else {
                StopAll();
                a[0].Play();
            }
        }
        else if (m.checkpoint == 1) {
            if (a[1].isPlaying)
                return;
            else {
                StopAll();
                a[1].Play();
            }
        }
        else if (m.checkpoint == 2) {
            if (a[2].isPlaying)
                return;
            else {
                StopAll();
                a[2].Play();
            }
        }
        else if (m.checkpoint == 3) {
            /*if (a[3].isPlaying)
                return;
            else {
                StopAll();
                a[3].Play();
            }*/
        }
    }

    void StopAll() {
        a[0].Stop();
        a[1].Stop();
        a[2].Stop();
        //a[3].Stop();
    }
}