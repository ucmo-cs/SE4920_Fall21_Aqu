using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CloudScroll : MonoBehaviour {

    public Material m;

    Vector2 offset;

    public float xVelocity, yVelocity;

    private void Awake() {
        
    }

    void Start() {
        offset = new Vector2(xVelocity, yVelocity);
    }

    void Update() {
        m.mainTextureOffset += offset * Time.deltaTime / 20;
    }
}