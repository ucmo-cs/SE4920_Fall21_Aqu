using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TutorialFade : MonoBehaviour {

    public SpriteRenderer sr;
    float x = 0.2f;
    int y = 1;

    void Awake() {
        sr.GetComponent<SpriteRenderer>();
    }

    void Update() {
        //////////////////////////////////// Tutorial Buttons
        if (x >= .95)
            y = -1;
        else if (x <= .2)
            y = 1;

        sr.color = new Color(sr.color.r, sr.color.g, sr.color.b, x);
        x += 0.0015f * y;
        ////////////////////////////////////
    }
}