using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class MainMenuStuff : MonoBehaviour {

    public Canvas start;

    //public PauseGame pg;

    private Movement m;

    void Start() {
        m = GameObject.FindGameObjectWithTag("Player").GetComponent<Movement>();
    }

    // Update is called once per frame
    void Update() {
        
    }

    public void startButton() {
        m.unfade();
        start.enabled = false;
    }

    void optionsButton() {

    }

    void quitButton() {
        Application.Quit();
    }
}