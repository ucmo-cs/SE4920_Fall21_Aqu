using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIHelper : MonoBehaviour {

    public int next = 0;

    public GameObject fadeSquare;
    private Movement m;

    private bool notFading = true;

    // Start is called before the first frame update
    void Awake() {
        fadeSquare = GameObject.FindGameObjectWithTag("fade");
        m = GameObject.FindGameObjectWithTag("Player").GetComponent<Movement>();
    }

    private void Start() {
        StartCoroutine(fade(false));
    }

    // Update is called once per frame
    void Update() {
        //////////////////////////////////// Fading
        if (m.respawn == 1 && notFading) {
            Debug.Log("test");
            StartCoroutine(fade());
            notFading = false;
        }
        if (m.respawn == 3) {
            notFading = true;
            StartCoroutine(fade(false));
            if (m.isHandled) {
                m.respawn = 0;
                m.isHandled = false;
                m.health = 100f;
                m.canMove = true;
            }
        }
    }

    public IEnumerator fade(bool ftb = true, int speed = 1) {

        Color c = fadeSquare.GetComponent<Image>().color;
        float fadeAmount;

        if (ftb) {
            while (fadeSquare.GetComponent<Image>().color.a < 1) {
                fadeAmount = c.a + (speed * Time.deltaTime);

                c = new Color(c.r, c.g, c.b, fadeAmount);
                fadeSquare.GetComponent<Image>().color = c;
                yield return null;
            }
            if (m.isHandled)
                m.respawn = 2;
        }

        else {
            while (fadeSquare.GetComponent<Image>().color.a > 0) {
                fadeAmount = c.a - (speed * Time.deltaTime);

                c = new Color(c.r, c.g, c.b, fadeAmount);
                fadeSquare.GetComponent<Image>().color = c;
                yield return null;
            }
        }
    }
}