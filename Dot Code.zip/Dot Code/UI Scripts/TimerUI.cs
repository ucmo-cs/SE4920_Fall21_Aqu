using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TimerUI : MonoBehaviour {

    public Text t;
    int time;
    int minute;
    int tens;
    int ones;

    void Start() {
        time = 0;
        minute = 0;
        tens = 0;
        ones = 0;
    }

    void Update() {
        if (Time.time >= time + 1) {
            ones++;
            if (ones < 10)
                t.text = minute + ":" + tens + "" + ones;
            else
                t.text = minute + ":" + ones;

            if (ones == 59) {
                minute++;
                ones = -1;
            }
            time++;
        }
    }
}