using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PauseGame : MonoBehaviour {

    private GameObject p_menu;
    private GameObject o_menu;
    private GameObject s_menu;

    private Movement m;

    private bool is_Paused = false;

    private void Awake() {
        m = GameObject.FindGameObjectWithTag("Player").GetComponent<Movement>();
        //s_menu = GameObject.FindWithTag("StartMenu");
        p_menu = GameObject.FindWithTag("Pause");
        o_menu = GameObject.FindWithTag("Options");
    }

    void Start() {
        //s_menu.SetActive(true);
        p_menu.SetActive(false);
        o_menu.SetActive(false);
    }

    void Update() {
        if (Input.GetKeyDown(KeyCode.Escape) && !is_Paused)
            StopGame();
        else if (Input.GetKeyDown(KeyCode.Escape) && is_Paused)
            ResumeGame();
    }

    void StopGame() {
        Time.timeScale = 0;
        is_Paused = true;
        p_menu.SetActive(true);
    }

    public void ResumeGame() {
        Time.timeScale = 1;
        is_Paused = false;
        p_menu.SetActive(false);

        //if (s_menu.activeInHierarchy)
            //s_menu.SetActive(false);
        if (o_menu.activeInHierarchy)
            o_menu.SetActive(false);
    }

    public void ReturntoMain() {
        //if (s_menu.activeInHierarchy)
            //s_menu.SetActive(false);
        if (o_menu.activeInHierarchy)
            o_menu.SetActive(false);
        p_menu.SetActive(true);
    }

    public void OptionsMenuOpen() {
        if (p_menu.activeInHierarchy)
            p_menu.SetActive(false);

        //if (s_menu.activeInHierarchy)
            //s_menu.SetActive(false);

        o_menu.SetActive(true);
    }

    /*public void startGame() {
        if (s_menu.activeInHierarchy)
            s_menu.SetActive(false);

        m.unfade();
    }*/
}