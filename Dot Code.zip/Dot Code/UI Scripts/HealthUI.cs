using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HealthUI : MonoBehaviour {
    private Image health_UI;
    private Movement m;

    private float val;

    void Awake() {
        health_UI = GameObject.FindWithTag("HealthUI").GetComponent<Image>();
        m = GameObject.FindGameObjectWithTag("Player").GetComponent<Movement>();
    }

    void Update() {
        val = m.health / 100f;

        health_UI.fillAmount = val;
    }
}