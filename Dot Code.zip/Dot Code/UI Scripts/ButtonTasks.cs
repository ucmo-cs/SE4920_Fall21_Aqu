using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.UI;

public class ButtonTasks : MonoBehaviour {

    private PauseGame pg;

    public int song = 0;
    public AudioSource[] BGMusic;
    public AudioSource[] SFX;

    void Start() {
        pg = GameObject.FindWithTag("Player").GetComponent<PauseGame>();
    }

    void SaveQuitGame() {
        string p = pg.transform.position.x + "," + pg.transform.position.y;
        File.WriteAllText("Dot_Save.txt", p);
        Application.Quit();
    }

    void ResumeGame() {
        pg.ResumeGame();
    }

    void BacktoMain() {
        pg.ReturntoMain();
    }

    void OptionsMenu() {
        pg.OptionsMenuOpen();
    }

    /*void startGame() {
        pg.startGame();
    }*/

    void adjustBGSound() {
        if (BGMusic[0].isPlaying)
            song = 0;
        if (BGMusic[1].isPlaying)
            song = 1;
        if (BGMusic[2].isPlaying)
            song = 2;

        BGMusic[song].volume = GameObject.FindWithTag("VolumeBar").GetComponent<Slider>().value;
    }

    void adjustSFXSound() {
        for (int x = 0; x < SFX.Length; x++) {
            SFX[x].volume = GameObject.FindWithTag("SFXBar").GetComponent<Slider>().value;
        }
    }
}